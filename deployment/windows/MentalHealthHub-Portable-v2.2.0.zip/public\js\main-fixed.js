/**
 * Main Application
 * Initializes all app components when DOM is ready
 */

// Global state
let socket = null;
let themeManager = null;
let chatManager = null;
let forumManager = null;
let resourcesManager = null;

/**
 * Initialize Socket.IO connection
 */
function initializeSocket() {
  try {
    console.log('Initializing Socket.IO...');
    
    // Connect to server
    socket = io({
      reconnection: true,
      reconnectionDelay: 1000,
      reconnectionAttempts: 5
    });

    // Connection events
    socket.on('connect', () => {
      console.log('✓ Connected to server');
      UIUtils.updateConnectionStatus(true);
      UIUtils.showToast('Connected to server', 'success');
    });

    socket.on('disconnect', () => {
      console.log('✗ Disconnected from server');
      UIUtils.updateConnectionStatus(false);
      UIUtils.showToast('Disconnected from server', 'warning');
    });

    socket.on('connect_error', (error) => {
      console.error('Connection error:', error);
      UIUtils.updateConnectionStatus(false);
      UIUtils.showToast('Connection error', 'error');
    });

    // User count updates
    socket.on('userCount', (count) => {
      UIUtils.updateOnlineCount(count);
    });

    return socket;
  } catch (error) {
    console.error('Socket initialization error:', error);
    UIUtils.showToast('Failed to connect to server', 'error');
    return null;
  }
}

/**
 * Initialize navigation
 */
function initializeNavigation() {
  try {
    const navButtons = document.querySelectorAll('.nav-btn');
    const sections = document.querySelectorAll('.section');

    navButtons.forEach(button => {
      button.addEventListener('click', () => {
        const targetId = button.dataset.section;
        
        // Update active button
        navButtons.forEach(btn => btn.classList.remove('active'));
        button.classList.add('active');

        // Show target section
        sections.forEach(section => {
          section.classList.remove('active');
        });
        
        const targetSection = document.getElementById(targetId);
        if (targetSection) {
          targetSection.classList.add('active');
        }

        console.log(`Navigated to: ${targetId}`);
      });
    });

    console.log('✓ Navigation initialized');
  } catch (error) {
    console.error('Navigation initialization error:', error);
  }
}

/**
 * Initialize all app components
 */
async function initializeApp() {
  try {
    console.log('🏥 Mental Health Hub - Initializing...');

    // 1. Initialize navigation
    initializeNavigation();

    // 2. Initialize theme manager
    if (typeof ThemeManager !== 'undefined') {
      themeManager = new ThemeManager();
      console.log('✓ Theme manager initialized');
    }

    // 3. Initialize Socket.IO
    socket = initializeSocket();
    
    if (!socket) {
      throw new Error('Failed to initialize socket connection');
    }

    // Wait a moment for socket to connect
    await new Promise(resolve => setTimeout(resolve, 500));

    // 4. Initialize managers with socket
    if (typeof ResourcesManager !== 'undefined') {
      resourcesManager = new ResourcesManager(socket);
      await resourcesManager.init();
      console.log('✓ Resources manager initialized');
    }

    if (typeof ChatManager !== 'undefined') {
      chatManager = new ChatManager(socket);
      console.log('✓ Chat manager initialized');
    }

    if (typeof ForumManager !== 'undefined') {
      forumManager = new ForumManager(socket);
      console.log('✓ Forum manager initialized');
    }

    console.log('✅ App initialized successfully');
    UIUtils.showToast('Welcome to Mental Health Hub!', 'success');

  } catch (error) {
    console.error('❌ App initialization error:', error);
    UIUtils.showToast('Failed to initialize app. Please refresh the page.', 'error');
  }
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initializeApp);
} else {
  // DOM already loaded
  initializeApp();
}

console.log('✓ Main.js loaded');
