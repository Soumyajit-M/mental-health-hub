/**
 * UI Utilities
 * Toast notifications, loading states, and common UI functions
 */

const UIUtils = {
  /**
   * Show toast notification
   */
  showToast(message, type = 'info') {
    try {
      const container = document.getElementById('toast-container');
      if (!container) {
        console.warn('Toast container not found');
        return;
      }

      const toast = document.createElement('div');
      toast.className = `toast ${type}`;
      
      const icons = {
        success: '✓',
        error: '✕',
        warning: '⚠',
        info: 'ℹ'
      };

      toast.innerHTML = `
        <span class="toast-icon">${icons[type] || icons.info}</span>
        <span class="toast-message">${this.escapeHtml(message)}</span>
      `;

      container.appendChild(toast);

      setTimeout(() => toast.classList.add('show'), 10);
      setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 300);
      }, 3000);
    } catch (error) {
      console.error('Toast error:', error);
    }
  },

  /**
   * Show loading overlay
   */
  showLoading() {
    try {
      const overlay = document.getElementById('loading-overlay');
      if (overlay) {
        overlay.classList.add('active');
      }
    } catch (error) {
      console.error('Loading overlay error:', error);
    }
  },

  /**
   * Hide loading overlay
   */
  hideLoading() {
    try {
      const overlay = document.getElementById('loading-overlay');
      if (overlay) {
        overlay.classList.remove('active');
      }
    } catch (error) {
      console.error('Loading overlay error:', error);
    }
  },

  /**
   * Escape HTML to prevent XSS
   */
  escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  },

  /**
   * Format timestamp
   */
  formatTimestamp(timestamp) {
    try {
      const date = new Date(timestamp);
      const now = new Date();
      const diff = now - date;

      if (diff < 60000) return 'Just now';
      if (diff < 3600000) {
        const minutes = Math.floor(diff / 60000);
        return `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
      }
      if (diff < 86400000) {
        const hours = Math.floor(diff / 3600000);
        return `${hours} hour${hours > 1 ? 's' : ''} ago`;
      }

      return date.toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    } catch (error) {
      return 'Recently';
    }
  },

  /**
   * Sanitize input
   */
  sanitizeInput(input) {
    if (typeof input !== 'string') return '';
    return input.trim().substring(0, 500);
  },

  /**
   * Validate message
   */
  validateMessage(message) {
    if (!message || message.trim().length === 0) {
      return { valid: false, error: 'Message cannot be empty' };
    }
    if (message.length > 500) {
      return { valid: false, error: 'Message is too long (max 500 characters)' };
    }
    return { valid: true, sanitized: this.sanitizeInput(message) };
  },

  /**
   * Update connection status UI
   */
  updateConnectionStatus(isConnected) {
    try {
      const statusEl = document.getElementById('connection-status');
      const statusDot = statusEl?.querySelector('.status-dot');
      const statusText = statusEl?.querySelector('.status-text');
      
      if (statusDot && statusText) {
        if (isConnected) {
          statusDot.classList.remove('disconnected');
          statusText.textContent = 'Connected';
        } else {
          statusDot.classList.add('disconnected');
          statusText.textContent = 'Disconnected';
        }
      }
    } catch (error) {
      console.error('Connection status error:', error);
    }
  },

  /**
   * Update online user count
   */
  updateOnlineCount(count) {
    try {
      const userCountEl = document.getElementById('user-count');
      if (userCountEl) {
        userCountEl.textContent = count;
      }
    } catch (error) {
      console.error('User count error:', error);
    }
  }
};

// Export
window.UIUtils = UIUtils;
console.log('✓ UIUtils loaded');
